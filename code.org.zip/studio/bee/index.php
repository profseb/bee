<?php

$game = "bee";
$default_stage = 7;

require_once "../framework/parser.php";