<?php

$game = "birds";
$default_stage = 4;

require_once "../framework/parser.php";